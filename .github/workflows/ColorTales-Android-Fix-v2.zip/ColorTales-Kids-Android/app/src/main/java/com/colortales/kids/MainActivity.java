package com.colortales.kids;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net/assets/www/";
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(113, 87, 217));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(255, 249, 233));
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(true);

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, android.webkit.WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            @SuppressWarnings("deprecation")
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, String url) {
                return assetLoader.shouldInterceptRequest(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new DownloadsBridge(), "AndroidDownloads");
        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, size) -> {
            String name = filenameFrom(contentDisposition, url, mimeType);
            if (url.startsWith("blob:")) {
                String js = "fetch(" + quote(url) + ").then(r=>r.blob()).then(b=>{const f=new FileReader();f.onload=()=>AndroidDownloads.save(f.result," + quote(name) + ");f.readAsDataURL(b)})";
                webView.evaluateJavascript(js, null);
            } else if (url.startsWith(APP_ORIGIN)) {
                saveAsset(url.substring(APP_ORIGIN.length()), name, mimeType);
            }
        });

        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 9);
        }

        if (savedInstanceState == null) webView.loadUrl(APP_ORIGIN + "index.html");
        else webView.restoreState(savedInstanceState);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private String quote(String value) {
        return "\"" + value.replace("\\", "\\\\").replace("\"", "\\\"") + "\"";
    }

    private String filenameFrom(String disposition, String url, String mime) {
        if (disposition != null && disposition.contains("filename=")) {
            return disposition.substring(disposition.indexOf("filename=") + 9).replace("\"", "").trim();
        }
        String last = Uri.parse(url).getLastPathSegment();
        if (last != null && last.contains(".")) return last;
        String ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        return "ColorTales-" + System.currentTimeMillis() + "." + (ext == null ? "bin" : ext);
    }

    private void saveAsset(String assetPath, String name, String mime) {
        try (InputStream input = getAssets().open("www/" + assetPath)) {
            saveStream(input, name, mime == null ? "application/octet-stream" : mime);
        } catch (Exception error) {
            Toast.makeText(this, "Could not save file", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveBytes(byte[] bytes, String name, String mime) throws Exception {
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Downloads.DISPLAY_NAME, name);
            values.put(MediaStore.Downloads.MIME_TYPE, mime);
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ColorTales Kids");
            Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Download destination unavailable");
            try (OutputStream output = getContentResolver().openOutputStream(uri)) { output.write(bytes); }
        } else {
            File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ColorTales Kids");
            if (!dir.exists() && !dir.mkdirs()) throw new Exception("Cannot create folder");
            try (OutputStream output = new FileOutputStream(new File(dir, name))) { output.write(bytes); }
        }
        Toast.makeText(this, "Saved to Downloads", Toast.LENGTH_SHORT).show();
    }

    private void saveStream(InputStream input, String name, String mime) throws Exception {
        byte[] buffer = new byte[8192];
        java.io.ByteArrayOutputStream bytes = new java.io.ByteArrayOutputStream();
        int read;
        while ((read = input.read(buffer)) != -1) bytes.write(buffer, 0, read);
        saveBytes(bytes.toByteArray(), name, mime);
    }

    public class DownloadsBridge {
        @JavascriptInterface
        public void save(String dataUrl, String name) {
            runOnUiThread(() -> {
                try {
                    int comma = dataUrl.indexOf(',');
                    String header = dataUrl.substring(0, comma);
                    String mime = header.substring(5, header.indexOf(';'));
                    saveBytes(Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT), name, mime);
                } catch (Exception error) {
                    Toast.makeText(MainActivity.this, "Could not save file", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}

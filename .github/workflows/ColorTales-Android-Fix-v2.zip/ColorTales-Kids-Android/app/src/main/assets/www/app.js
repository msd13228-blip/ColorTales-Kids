const coverIcons=['🌈','⭐','🪄','🌙','🦋','🏰','🌻','🐻','🎈','🍄'];
const storyTitles=['Little Red Riding Hood','Cinderella','Rapunzel','Hansel and Gretel','The Frog Prince','Sleeping Beauty','Puss in Boots','Tom Thumb','The Elves and the Shoemaker','Goldilocks and the Three Bears'];
const slugs=['red-riding-hood','cinderella','rapunzel','hansel-gretel','frog-prince','sleeping-beauty','puss-in-boots','tom-thumb','elves-shoemaker','goldilocks-three-bears'];
const stories=storyTitles.map((title,i)=>({id:i+1,title,free:i<2,ready:i<10,icon:coverIcons[i],slug:slugs[i]||''}));
const littleRedPages=[
  {text:'One morning, Little Red Riding Hood’s mother packed a basket for Grandmother.',image:'assets/red-riding-hood/page-01.png'},
  {text:'“Stay on the path,” said Mother. Little Red Riding Hood happily walked into the forest.',image:'assets/red-riding-hood/page-02.png'},
  {text:'On the path, she met a wolf who asked where she was going.',image:'assets/red-riding-hood/page-03.png'},
  {text:'The clever wolf showed her a patch of beautiful flowers beside the path.',image:'assets/red-riding-hood/page-04.png'},
  {text:'While she looked at the flowers, the wolf hurried toward Grandmother’s cottage.',image:'assets/red-riding-hood/page-05.png'},
  {text:'Little Red Riding Hood picked a bright bouquet for Grandmother.',image:'assets/red-riding-hood/page-06.png'},
  {text:'The wolf reached the cottage first and knocked on the little door.',image:'assets/red-riding-hood/page-07.png'},
  {text:'Grandmother hid safely in the wardrobe while the wolf put on her nightcap.',image:'assets/red-riding-hood/page-08.png'},
  {text:'Little Red Riding Hood arrived. “Grandmother, what big ears you have!” she said.',image:'assets/red-riding-hood/page-09.png'},
  {text:'A kind forest ranger came to help, and the wolf quickly ran back to the woods.',image:'assets/red-riding-hood/page-10.png'},
  {text:'Color all the characters from the story!',image:'assets/red-riding-hood/characters.png',final:true}
];
const cinderellaPages=[
  {text:'Cinderella worked hard each day, but she stayed kind and hopeful.',image:'assets/cinderella/page-01.png'},
  {text:'One day, a royal invitation arrived for a grand ball at the palace.',image:'assets/cinderella/page-02.png'},
  {text:'Her stepmother and stepsisters left for the ball without Cinderella.',image:'assets/cinderella/page-03.png'},
  {text:'Then her fairy godmother appeared and promised to help.',image:'assets/cinderella/page-04.png'},
  {text:'With a wave of her wand, a pumpkin became a beautiful carriage.',image:'assets/cinderella/page-05.png'},
  {text:'Cinderella arrived at the palace, and the prince welcomed her warmly.',image:'assets/cinderella/page-06.png'},
  {text:'Cinderella and the prince danced happily through the evening.',image:'assets/cinderella/page-07.png'},
  {text:'At midnight, Cinderella hurried away and left one glass slipper behind.',image:'assets/cinderella/page-08.png'},
  {text:'The prince searched the kingdom for the person whose foot fit the slipper.',image:'assets/cinderella/page-09.png'},
  {text:'The slipper fit Cinderella perfectly, and everyone learned who she was.',image:'assets/cinderella/page-10.png'},
  {text:'Color all the characters from the story!',image:'assets/cinderella/characters.png',final:true}
];
const rapunzelPages=[
 {text:'A loving couple lived beside a beautiful walled garden and dreamed of having a child.',image:'assets/rapunzel/page-01.png'},
 {text:'One evening, the father gathered rapunzel leaves and met the stern sorceress.',image:'assets/rapunzel/page-02.png'},
 {text:'Years later, Rapunzel grew into a kind young woman who lived in a cozy tower.',image:'assets/rapunzel/page-03.png'},
 {text:'The sorceress reached the tower by climbing Rapunzel’s long flowered braid.',image:'assets/rapunzel/page-04.png'},
 {text:'A prince riding through the forest heard Rapunzel’s beautiful singing.',image:'assets/rapunzel/page-05.png'},
 {text:'He quietly watched and learned how the sorceress reached the tower.',image:'assets/rapunzel/page-06.png'},
 {text:'When the sorceress had gone, the prince called politely for Rapunzel to lower her braid.',image:'assets/rapunzel/page-07.png'},
 {text:'Rapunzel welcomed the friendly visitor, and they quickly became friends.',image:'assets/rapunzel/page-08.png'},
 {text:'The prince returned with books and flowers, filling the tower with happy stories.',image:'assets/rapunzel/page-09.png'},
 {text:'Together, they planned a safe way for Rapunzel to leave the tower.',image:'assets/rapunzel/page-10.png'},
 {text:'The sorceress discovered the woven ladder and realized their plan.',image:'assets/rapunzel/page-11.png'},
 {text:'Rapunzel was sent to a quiet woodland cottage, where she stayed safe and hopeful.',image:'assets/rapunzel/page-12.png'},
 {text:'The prince found the tower empty and began searching the forest for his friend.',image:'assets/rapunzel/page-13.png'},
 {text:'One day, he heard Rapunzel singing near a small cottage among the trees.',image:'assets/rapunzel/page-14.png'},
 {text:'Rapunzel and the prince were happily reunited and began a new life together.',image:'assets/rapunzel/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/rapunzel/characters.png',final:true}
];
const hanselGretelPages=[
 {text:'Hansel and Gretel lived in a small cottage with their father and stepmother.',image:'assets/hansel-gretel/page-01.png'},
 {text:'Hansel quietly gathered white pebbles before they walked into the forest.',image:'assets/hansel-gretel/page-02.png'},
 {text:'As the family walked, Hansel dropped the pebbles along the path.',image:'assets/hansel-gretel/page-03.png'},
 {text:'That night, the children waited bravely beside a small fire.',image:'assets/hansel-gretel/page-04.png'},
 {text:'At sunrise, the shining pebbles guided Hansel and Gretel safely home.',image:'assets/hansel-gretel/page-05.png'},
 {text:'On another morning, Hansel saved bread crumbs to mark the forest path.',image:'assets/hansel-gretel/page-06.png'},
 {text:'But little birds ate the crumbs as the family walked deeper into the woods.',image:'assets/hansel-gretel/page-07.png'},
 {text:'Hansel and Gretel found the path empty, but they stayed together.',image:'assets/hansel-gretel/page-08.png'},
 {text:'Soon they discovered a wonderful cottage made of gingerbread and sweets.',image:'assets/hansel-gretel/page-09.png'},
 {text:'An old woman opened the door and invited the children inside.',image:'assets/hansel-gretel/page-10.png'},
 {text:'She offered them a meal, but Hansel and Gretel watched her carefully.',image:'assets/hansel-gretel/page-11.png'},
 {text:'When the witch showed Gretel the oven, Gretel made a clever plan.',image:'assets/hansel-gretel/page-12.png'},
 {text:'Gretel shut the oven door, and the children were safe from the witch.',image:'assets/hansel-gretel/page-13.png'},
 {text:'Hansel and Gretel found a small treasure and prepared to go home.',image:'assets/hansel-gretel/page-14.png'},
 {text:'Their father welcomed them home with the happiest hug.',image:'assets/hansel-gretel/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/hansel-gretel/characters.png',final:true}
];
const frogPrincePages=[
 {text:'The princess loved playing with her golden ball in the palace garden.',image:'assets/frog-prince/page-01.png'},
 {text:'One day, the golden ball rolled into a deep pond.',image:'assets/frog-prince/page-02.png'},
 {text:'A friendly frog appeared and offered to help her.',image:'assets/frog-prince/page-03.png'},
 {text:'The princess promised to be his friend if he found the ball.',image:'assets/frog-prince/page-04.png'},
 {text:'The frog dived into the pond and reached the golden ball.',image:'assets/frog-prince/page-05.png'},
 {text:'He returned the ball, and the princess thanked him with delight.',image:'assets/frog-prince/page-06.png'},
 {text:'The princess walked back to the palace while the frog followed.',image:'assets/frog-prince/page-07.png'},
 {text:'Soon the frog arrived at the palace door and politely knocked.',image:'assets/frog-prince/page-08.png'},
 {text:'The king reminded the princess that promises should be kept.',image:'assets/frog-prince/page-09.png'},
 {text:'The princess kindly shared her meal with her new friend.',image:'assets/frog-prince/page-10.png'},
 {text:'She brought the frog a soft cushion in a cozy palace room.',image:'assets/frog-prince/page-11.png'},
 {text:'The princess read him a story, and their friendship grew.',image:'assets/frog-prince/page-12.png'},
 {text:'Her kindness broke the spell, and the frog became a prince.',image:'assets/frog-prince/page-13.png'},
 {text:'The prince explained the spell while the king listened happily.',image:'assets/frog-prince/page-14.png'},
 {text:'The princess, the prince, and the king celebrated in the garden.',image:'assets/frog-prince/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/frog-prince/characters.png',final:true}
];
const sleepingBeautyPages=[
 {text:'The palace prepared a joyful birthday celebration for Princess Aurora.',image:'assets/sleeping-beauty/page-01.png'},
 {text:'A kind fairy blessed Aurora with courage, kindness, and hope.',image:'assets/sleeping-beauty/page-02.png'},
 {text:'The fairy warned the king and queen about an enchanted spinning wheel.',image:'assets/sleeping-beauty/page-03.png'},
 {text:'The king carefully removed every spinning wheel from the palace.',image:'assets/sleeping-beauty/page-04.png'},
 {text:'Aurora grew into a gentle princess who loved the palace gardens.',image:'assets/sleeping-beauty/page-05.png'},
 {text:'One sunny day, Aurora discovered an old craft room in a quiet tower.',image:'assets/sleeping-beauty/page-06.png'},
 {text:'Gentle magic filled the room, and Aurora became very sleepy.',image:'assets/sleeping-beauty/page-07.png'},
 {text:'The kind fairy kept Aurora safe in a peaceful flower-filled chamber.',image:'assets/sleeping-beauty/page-08.png'},
 {text:'The fairy let the whole palace rest until the enchantment could end.',image:'assets/sleeping-beauty/page-09.png'},
 {text:'A beautiful wall of roses grew around the sleeping castle.',image:'assets/sleeping-beauty/page-10.png'},
 {text:'Years later, a young prince read the old story of the rose-covered castle.',image:'assets/sleeping-beauty/page-11.png'},
 {text:'The prince followed the story and arrived at the castle gate.',image:'assets/sleeping-beauty/page-12.png'},
 {text:'The kind fairy opened a safe path through the flowering roses.',image:'assets/sleeping-beauty/page-13.png'},
 {text:'The prince rang a silver bell, and Aurora opened her eyes.',image:'assets/sleeping-beauty/page-14.png'},
 {text:'Aurora, the prince, the royal family, and the fairy celebrated together.',image:'assets/sleeping-beauty/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/sleeping-beauty/characters.png',final:true}
];
const pussInBootsPages=[
 {text:'The miller’s son wondered what to do, but his clever cat had a plan.',image:'assets/puss-in-boots/page-01.png'},
 {text:'The cat asked for a pair of boots, a hat, a cape, and a small satchel.',image:'assets/puss-in-boots/page-02.png'},
 {text:'The miller’s son prepared the outfit, and the cat set off proudly.',image:'assets/puss-in-boots/page-03.png'},
 {text:'The cat gathered a lovely basket of vegetables and flowers from the meadow.',image:'assets/puss-in-boots/page-04.png'},
 {text:'He presented the basket to the king as a gift from his master.',image:'assets/puss-in-boots/page-05.png'},
 {text:'The clever cat studied the road and saw the royal carriage approaching.',image:'assets/puss-in-boots/page-06.png'},
 {text:'By the river, the cat brought his master an elegant coat.',image:'assets/puss-in-boots/page-07.png'},
 {text:'The kind king helped the young man dress for the royal journey.',image:'assets/puss-in-boots/page-08.png'},
 {text:'The young man politely met the princess, and they quickly became friends.',image:'assets/puss-in-boots/page-09.png'},
 {text:'The royal carriage continued while the clever cat hurried ahead.',image:'assets/puss-in-boots/page-10.png'},
 {text:'The cat asked the farmers to welcome his master along the road.',image:'assets/puss-in-boots/page-11.png'},
 {text:'At a grand castle, a boastful magician proudly showed the cat his home.',image:'assets/puss-in-boots/page-12.png'},
 {text:'The magician demonstrated his amazing shape-changing magic.',image:'assets/puss-in-boots/page-13.png'},
 {text:'The cat’s clever challenge sent the tiny magical creature safely away.',image:'assets/puss-in-boots/page-14.png'},
 {text:'The cat and his master happily welcomed everyone to their new home.',image:'assets/puss-in-boots/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/puss-in-boots/characters.png',final:true}
];
const tomThumbPages=[
 {text:'Tom Thumb was no taller than his father’s thumb, but he was brave and cheerful.',image:'assets/tom-thumb/page-01.png'},
 {text:'Tom happily helped his mother sort berries in their cozy cottage.',image:'assets/tom-thumb/page-02.png'},
 {text:'His father carried him safely through the forest on his shoulder.',image:'assets/tom-thumb/page-03.png'},
 {text:'At a crossroads, a traveling showman invited Tom to visit the village fair.',image:'assets/tom-thumb/page-04.png'},
 {text:'With his parents’ permission, Tom rode toward the fair in the traveler’s hat.',image:'assets/tom-thumb/page-05.png'},
 {text:'At the fair, Tom amazed everyone with a cheerful balancing trick.',image:'assets/tom-thumb/page-06.png'},
 {text:'When the traveler became busy counting coins, clever Tom quietly continued his journey.',image:'assets/tom-thumb/page-07.png'},
 {text:'Tom rested in a soft hay cart that rolled toward a distant castle.',image:'assets/tom-thumb/page-08.png'},
 {text:'The castle guards were delighted to meet such a tiny and confident visitor.',image:'assets/tom-thumb/page-09.png'},
 {text:'Inside the castle, a precious key had fallen beneath a narrow floor grate.',image:'assets/tom-thumb/page-10.png'},
 {text:'Tom volunteered to slip through the grate while a guard held a strong ribbon.',image:'assets/tom-thumb/page-11.png'},
 {text:'In the chamber below, Tom found the key and lifted it proudly.',image:'assets/tom-thumb/page-12.png'},
 {text:'The grateful king thanked Tom with a medal and a small reward.',image:'assets/tom-thumb/page-13.png'},
 {text:'A royal carriage carried Tom safely back to his family.',image:'assets/tom-thumb/page-14.png'},
 {text:'Tom’s parents welcomed him home and celebrated his clever adventure.',image:'assets/tom-thumb/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/tom-thumb/characters.png',final:true}
];
const elvesShoemakerPages=[
 {text:'A kind shoemaker and his wife had only enough leather left for one pair of shoes.',image:'assets/elves-shoemaker/page-01.png'},
 {text:'The shoemaker carefully cut the leather and left the pieces ready for morning.',image:'assets/elves-shoemaker/page-02.png'},
 {text:'That night, two little elves quietly entered the sleeping workshop.',image:'assets/elves-shoemaker/page-03.png'},
 {text:'The elves stitched the leather into a beautiful pair of shoes.',image:'assets/elves-shoemaker/page-04.png'},
 {text:'At sunrise, the shoemaker and his wife discovered the finished shoes.',image:'assets/elves-shoemaker/page-05.png'},
 {text:'A delighted customer bought the shoes and paid a generous price.',image:'assets/elves-shoemaker/page-06.png'},
 {text:'The shoemaker used the money to buy leather for several more pairs.',image:'assets/elves-shoemaker/page-07.png'},
 {text:'That night, the two elves returned and worked together again.',image:'assets/elves-shoemaker/page-08.png'},
 {text:'Soon, happy customers filled the workshop to buy the wonderful shoes.',image:'assets/elves-shoemaker/page-09.png'},
 {text:'The shoemaker and his wife wondered who was helping them each night.',image:'assets/elves-shoemaker/page-10.png'},
 {text:'They quietly hid behind a curtain to watch the workshop after dark.',image:'assets/elves-shoemaker/page-11.png'},
 {text:'At midnight, they saw the two elves happily sewing the shoes.',image:'assets/elves-shoemaker/page-12.png'},
 {text:'The couple noticed that the elves’ little clothes were old and patched.',image:'assets/elves-shoemaker/page-13.png'},
 {text:'They made two tiny outfits and two pairs of boots as thank-you gifts.',image:'assets/elves-shoemaker/page-14.png'},
 {text:'The elves found the gifts, dressed happily, and danced with joy.',image:'assets/elves-shoemaker/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/elves-shoemaker/characters.png',final:true}
];
const goldilocksPages=[
 {text:'The three bears made porridge for breakfast, but it was too hot to eat.',image:'assets/goldilocks-three-bears/page-01.png'},
 {text:'Papa Bear, Mama Bear, and Baby Bear went for a walk while the porridge cooled.',image:'assets/goldilocks-three-bears/page-02.png'},
 {text:'Goldilocks found their little cottage in a sunny forest clearing.',image:'assets/goldilocks-three-bears/page-03.png'},
 {text:'She knocked on the door, but no one answered, so she quietly looked inside.',image:'assets/goldilocks-three-bears/page-04.png'},
 {text:'Goldilocks tasted Papa Bear’s porridge. “This is too hot!” she said.',image:'assets/goldilocks-three-bears/page-05.png'},
 {text:'She tasted Mama Bear’s porridge. “This is too cold!” she said.',image:'assets/goldilocks-three-bears/page-06.png'},
 {text:'Then she tasted Baby Bear’s porridge. It was just right, so she ate it all.',image:'assets/goldilocks-three-bears/page-07.png'},
 {text:'Goldilocks tried the chairs, but Baby Bear’s little chair cracked beneath her.',image:'assets/goldilocks-three-bears/page-08.png'},
 {text:'Feeling tired, Goldilocks climbed the stairs to look for a place to rest.',image:'assets/goldilocks-three-bears/page-09.png'},
 {text:'Papa Bear’s bed was too hard for Goldilocks.',image:'assets/goldilocks-three-bears/page-10.png'},
 {text:'Mama Bear’s bed was too soft for Goldilocks.',image:'assets/goldilocks-three-bears/page-11.png'},
 {text:'Baby Bear’s bed was just right, and Goldilocks soon fell asleep.',image:'assets/goldilocks-three-bears/page-12.png'},
 {text:'The three bears came home and discovered that someone had tasted their porridge.',image:'assets/goldilocks-three-bears/page-13.png'},
 {text:'Upstairs, the bears found Goldilocks awake in Baby Bear’s bed.',image:'assets/goldilocks-three-bears/page-14.png'},
 {text:'Goldilocks apologized, waved goodbye, and followed the safe path home.',image:'assets/goldilocks-three-bears/page-15.png'},
 {text:'Color all the characters from the story!',image:'assets/goldilocks-three-bears/characters.png',final:true}
];
const drawings={};
const app=document.querySelector('#app');
let route='home';

function header(title,subtitle=''){
  return `<div class="section-head"><div><span class="eyebrow">ColorTales Kids</span><h2>${title}</h2></div><small>${subtitle}</small></div>`;
}
function storyCards(items){
  return `<div class="cards">${items.map(s=>`<button class="card ${s.free?'':'locked'} ${s.ready?'ready-story':''}" data-story="${s.id}"><div class="cover" ${s.ready?`style="background-image:url('assets/${s.slug}/cover.png')"`:''}>${s.ready?'':`<span>${s.icon}</span>`}</div>${s.free?'<span class="badge">FREE</span>':'<span class="lock-bubble">🔒</span>'}<h3>${s.title}</h3><p class="meta">${s.ready?'Read & color now':'A new adventure is coming!'}</p></button>`).join('')}</div>`;
}
function home(){
  return `<div class="shell"><section class="hero"><div class="hero-doodles" aria-hidden="true"><b>★</b><b>✿</b><b>●</b></div><div class="eyebrow">Read • Color • Play</div><h1>Let’s color a story!</h1><p>Pick a magical tale and fill every page with your favorite colors.</p><div class="pencil-row" aria-hidden="true">🖍️ ✨ 🎨</div></section>${header('Pick an adventure','2 free • 8 premium')}${storyCards(stories.slice(0,4))}<div style="height:18px"></div><button class="cta" data-unlock><span>🌟</span> Unlock All Stories</button></div>`;
}
function library(){
  return `<div class="shell">${header('Story Library','10 spaces ready')}${storyCards(stories)}</div>`;
}
function parents(){
  return `<div class="shell">${header('Parents Area')}<section class="parents-card"><h3>Premium Library</h3><p>Unlock all eight premium story spaces with one purchase.</p><button class="cta" data-unlock>Unlock All Stories</button></section><section class="parents-card"><h3>Restore Purchase</h3><p>Restore a previous Google Play purchase on this device.</p><button class="cta secondary" data-demo>Restore Purchase</button></section><section class="parents-card"><h3>Safe for children</h3><p>No chat, no external social links, and no advertising is included in this starter version.</p></section><section class="parents-card"><h3>About</h3><p>Version 0.1 • Starter shell without story content.</p></section></div>`;
}
function render(){app.innerHTML=route==='home'?home():route==='library'?library():parents();document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.route===route));bind();}
function modal(title,body,action='Got it'){
  const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="sheet"><button class="close">×</button><h2>${title}</h2>${body}<button class="cta">${action}</button></div>`;document.body.appendChild(m);m.querySelectorAll('button').forEach(b=>b.onclick=()=>m.remove());
}
function bind(){
  document.querySelectorAll('[data-story]').forEach(el=>el.onclick=()=>Number(el.dataset.story)<=10?openStory(Number(el.dataset.story)):modal('Story space ready','<p>This place is prepared for a story, cover, page text, and coloring artwork. No story content has been added yet.</p>'));
  document.querySelectorAll('[data-unlock]').forEach(el=>el.onclick=()=>modal('Unlock All Stories','<p>Google Play Billing will be connected here before publishing. The final price can be chosen later.</p><div class="price">Price later</div>','Continue'));
  document.querySelectorAll('[data-demo]').forEach(el=>el.onclick=()=>modal('Restore Purchase','<p>Purchase restoration will become active after Google Play Billing is connected.</p>'));
}
function openStory(storyId=1){
  const isCinderella=storyId===2,isRapunzel=storyId===3,isHanselGretel=storyId===4,isFrogPrince=storyId===5,isSleepingBeauty=storyId===6,isPussInBoots=storyId===7,isTomThumb=storyId===8,isElvesShoemaker=storyId===9,isGoldilocks=storyId===10;
  const pages=isGoldilocks?goldilocksPages:isElvesShoemaker?elvesShoemakerPages:isTomThumb?tomThumbPages:isPussInBoots?pussInBootsPages:isSleepingBeauty?sleepingBeautyPages:isFrogPrince?frogPrincePages:isHanselGretel?hanselGretelPages:isRapunzel?rapunzelPages:isCinderella?cinderellaPages:littleRedPages;
  const title=isGoldilocks?'Goldilocks and the Three Bears':isElvesShoemaker?'The Elves and the Shoemaker':isTomThumb?'Tom Thumb':isPussInBoots?'Puss in Boots':isSleepingBeauty?'Sleeping Beauty':isFrogPrince?'The Frog Prince':isHanselGretel?'Hansel and Gretel':isRapunzel?'Rapunzel':isCinderella?'Cinderella':'Little Red Riding Hood';
  const slug=isGoldilocks?'goldilocks-three-bears':isElvesShoemaker?'elves-shoemaker':isTomThumb?'tom-thumb':isPussInBoots?'puss-in-boots':isSleepingBeauty?'sleeping-beauty':isFrogPrince?'frog-prince':isHanselGretel?'hansel-gretel':isRapunzel?'rapunzel':isCinderella?'cinderella':'red-riding-hood';
  const pdfName=isGoldilocks?'Goldilocks-and-the-Three-Bears-Coloring-Story.pdf':isElvesShoemaker?'The-Elves-and-the-Shoemaker-Coloring-Story.pdf':isTomThumb?'Tom-Thumb-Coloring-Story.pdf':isPussInBoots?'Puss-in-Boots-Coloring-Story.pdf':isSleepingBeauty?'Sleeping-Beauty-Coloring-Story.pdf':isFrogPrince?'The-Frog-Prince-Coloring-Story.pdf':isHanselGretel?'Hansel-and-Gretel-Coloring-Story.pdf':isRapunzel?'Rapunzel-Coloring-Story.pdf':isCinderella?'Cinderella-Coloring-Story.pdf':'Little-Red-Riding-Hood-Coloring-Story.pdf';
  const redPages=pages;
  let page=-1,color='#ef3e4d',drawing=false,last=null,zoom=1,moveMode=false,tool='fill',brushSize=24;
  const reader=document.createElement('section');reader.className='story-reader';document.body.appendChild(reader);
  const drawingKey=()=>`colortales-coloring:${slug}:${page}`;
  function save(){
    const c=reader.querySelector('#paint');
    if(!c||page<0)return;
    const data=c.toDataURL('image/png');
    drawings[drawingKey()]=data;
    try{localStorage.setItem(drawingKey(),data)}catch(error){console.warn('Coloring save is full',error)}
  }
  function draw(){
    const cover=page===-1,item=cover?null:redPages[page];
    reader.innerHTML=`<header class="reader-head"><button class="reader-close" aria-label="Close story">←</button><div><strong>Little Red Riding Hood</strong><small>${cover?'Cover':`Page ${page+1} of ${redPages.length}`}</small></div><a class="head-pdf" href="Little-Red-Riding-Hood-Coloring-Story.pdf" download>PDF</a></header><div class="reader-body">${cover?`<div class="story-cover"><img src="assets/red-riding-hood/cover.png" alt="Little Red Riding Hood cover"><div class="cover-title"><span>Read & Color</span><h1>Little Red<br>Riding Hood</h1></div></div><a class="download-pdf" href="Little-Red-Riding-Hood-Coloring-Story.pdf" download>⬇ Download PDF</a>`:`<div class="story-copy">${item.text}</div><div class="color-stage"><div class="art-board"><img id="pageArt" src="${item.image}" alt="Coloring scene"><canvas id="paint"></canvas></div></div><button class="start-coloring">🖍️ Start Coloring</button><div class="color-toolbar"><button class="zoom-out" aria-label="Zoom out">−</button><button class="move-canvas" aria-label="Move picture">✋ Move</button><button class="zoom-in" aria-label="Zoom in">+</button><button class="done-coloring">Done</button></div><div class="color-controls"><div class="tool-row"><button data-tool="fill" class="selected">🪣 Fill</button><button data-tool="brush">🖌️ Brush</button><button data-tool="erase">⌫ Erase</button><button class="undo" aria-label="Undo">↶</button><button class="redo" aria-label="Redo">↷</button><button class="compare" aria-label="Compare with original">◐</button></div><div class="size-row" aria-label="Brush size"><span>Size</span><button data-size="12">S</button><button data-size="24" class="selected">M</button><button data-size="42">L</button><button class="save-image">Image</button><button class="save-colored-pdf">PDF</button><button class="clear-paint">Clear</button></div><div class="palette">${['#ef3e4d','#ff8b32','#ffd43b','#53c96b','#42a5f5','#7652d6','#ee64b3','#754c2f'].map(c=>`<button data-color="${c}" style="--c:${c}" aria-label="Choose color"></button>`).join('')}</div></div>`}</div><footer class="reader-nav"><button class="prev" ${page===-1?'disabled':''}>Previous</button><span>${cover?'●':`${page+1} / ${redPages.length}`}</span><button class="next">${page===redPages.length-1?'Finish':'Next'}</button></footer>`;
    if(isCinderella||isRapunzel||isHanselGretel||isFrogPrince||isSleepingBeauty||isPussInBoots||isTomThumb||isElvesShoemaker||isGoldilocks){
      reader.querySelector('.reader-head strong').textContent=title;
      reader.querySelectorAll('a[href="Little-Red-Riding-Hood-Coloring-Story.pdf"]').forEach(a=>a.href=pdfName);
      const coverImage=reader.querySelector('.story-cover img');
      if(coverImage){coverImage.src=`assets/${slug}/cover.png`;coverImage.alt=`${title} cover`;reader.querySelector('.cover-title h1').textContent=title;}
    }
    reader.querySelector('.reader-close').onclick=()=>{save();reader.remove()};
    reader.querySelector('.prev').onclick=()=>{save();page--;draw()};
    reader.querySelector('.next').onclick=()=>{if(page===redPages.length-1){reader.remove();return}save();page++;draw()};
    if(!cover)setupCanvas();
  }
  function setupCanvas(){
    tool='fill';brushSize=24;
    const img=reader.querySelector('#pageArt'),c=reader.querySelector('#paint'),ctx=c.getContext('2d',{willReadFrequently:true}),board=reader.querySelector('.art-board'),stage=reader.querySelector('.color-stage');
    const base=document.createElement('canvas'),baseCtx=base.getContext('2d',{willReadFrequently:true});
    const stroke=document.createElement('canvas'),strokeCtx=stroke.getContext('2d');
    const maskCanvas=document.createElement('canvas'),maskCtx=maskCanvas.getContext('2d');
    let basePixels=null,regionMask=null,undoStack=[],redoStack=[],compare=false;
    const saved=()=>drawings[drawingKey()]||(()=>{try{return localStorage.getItem(drawingKey())}catch{return null}})();
    const snapshot=()=>c.toDataURL('image/png');
    const restore=data=>new Promise(resolve=>{ctx.clearRect(0,0,c.width,c.height);if(!data){resolve();return}const old=new Image();old.onload=()=>{ctx.drawImage(old,0,0);resolve()};old.src=data});
    const record=()=>{undoStack.push(snapshot());if(undoStack.length>16)undoStack.shift();redoStack=[];save();updateHistory()};
    const updateHistory=()=>{reader.querySelector('.undo').disabled=undoStack.length<2;reader.querySelector('.redo').disabled=!redoStack.length};
    const init=()=>{
      c.width=base.width=stroke.width=maskCanvas.width=img.naturalWidth;
      c.height=base.height=stroke.height=maskCanvas.height=img.naturalHeight;
      baseCtx.drawImage(img,0,0,base.width,base.height);
      basePixels=baseCtx.getImageData(0,0,base.width,base.height).data;
      const old=saved();
      if(old){const restored=new Image();restored.onload=()=>{ctx.drawImage(restored,0,0);undoStack=[snapshot()];updateHistory()};restored.src=old}else{undoStack=[snapshot()];updateHistory()}
    };
    img.onload=init;if(img.complete&&img.naturalWidth)init();
    const point=e=>{const r=c.getBoundingClientRect();return{x:Math.max(0,Math.min(c.width-1,Math.floor((e.clientX-r.left)*c.width/r.width))),y:Math.max(0,Math.min(c.height-1,Math.floor((e.clientY-r.top)*c.height/r.height)))}};
    const hexRgb=hex=>[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16)];
    const barrier=i=>{const p=i*4;return (basePixels[p]+basePixels[p+1]+basePixels[p+2])/3<205};
    function makeRegion(x,y){
      if(!basePixels)return null;
      const w=c.width,h=c.height,start=y*w+x,n=w*h;
      if(barrier(start))return null;
      const mask=new Uint8ClampedArray(n),queue=new Uint32Array(n);let head=0,tail=0;
      mask[start]=255;queue[tail++]=start;
      while(head<tail){const i=queue[head++],px=i%w,py=(i/w)|0;let j;
        if(px>0){j=i-1;if(!mask[j]&&!barrier(j)){mask[j]=255;queue[tail++]=j}}
        if(px<w-1){j=i+1;if(!mask[j]&&!barrier(j)){mask[j]=255;queue[tail++]=j}}
        if(py>0){j=i-w;if(!mask[j]&&!barrier(j)){mask[j]=255;queue[tail++]=j}}
        if(py<h-1){j=i+w;if(!mask[j]&&!barrier(j)){mask[j]=255;queue[tail++]=j}}
      }
      return mask;
    }
    function prepareMask(mask){const data=maskCtx.createImageData(c.width,c.height);for(let i=0;i<mask.length;i++){const p=i*4;data.data[p]=data.data[p+1]=data.data[p+2]=255;data.data[p+3]=mask[i]}maskCtx.putImageData(data,0,0)}
    function fillRegion(p){
      const mask=makeRegion(p.x,p.y);if(!mask)return;
      const data=ctx.getImageData(0,0,c.width,c.height),rgb=hexRgb(color);
      for(let i=0;i<mask.length;i++)if(mask[i]){const q=i*4;data.data[q]=rgb[0];data.data[q+1]=rgb[1];data.data[q+2]=rgb[2];data.data[q+3]=210}
      ctx.putImageData(data,0,0);record();
    }
    function paintSegment(a,b){
      strokeCtx.clearRect(0,0,stroke.width,stroke.height);strokeCtx.globalCompositeOperation='source-over';strokeCtx.beginPath();strokeCtx.moveTo(a.x,a.y);strokeCtx.lineTo(b.x,b.y);strokeCtx.strokeStyle='#000';strokeCtx.lineWidth=brushSize;strokeCtx.lineCap='round';strokeCtx.lineJoin='round';strokeCtx.stroke();
      if(regionMask){strokeCtx.globalCompositeOperation='destination-in';strokeCtx.drawImage(maskCanvas,0,0)}
      ctx.globalCompositeOperation=tool==='erase'?'destination-out':'source-over';ctx.fillStyle=color;ctx.globalAlpha=tool==='erase'?1:.84;ctx.drawImage(stroke,0,0);ctx.globalAlpha=1;ctx.globalCompositeOperation='source-over';
    }
    c.onpointerdown=e=>{
      if(!reader.classList.contains('coloring')||moveMode||activeTouches.size>1)return;
      e.preventDefault();
      const p=point(e);if(tool==='fill'){fillRegion(p);return}
      regionMask=makeRegion(p.x,p.y);if(!regionMask)return;prepareMask(regionMask);drawing=true;last=p;paintSegment(p,p);
      try{c.setPointerCapture(e.pointerId)}catch{}
    };
    c.onpointermove=e=>{if(!drawing||activeTouches.size>1)return;e.preventDefault();const p=point(e);paintSegment(last,p);last=p};
    c.onpointerup=e=>{if(drawing){drawing=false;last=null;regionMask=null;record()}try{c.releasePointerCapture(e.pointerId)}catch{}};c.onpointercancel=c.onpointerup;
    const palette=reader.querySelector('.palette');
    const extraColors=['#ffb3c7','#c92d59','#9b1b30','#ffb067','#f5d6b8','#d79a6b','#a9633f','#63351f','#fff4d6','#c9a227','#a6e36f','#168b4b','#74dfd5','#167b8f','#9bd2ff','#2459a9','#b69cff','#4b2a91','#f0f0f0','#b8b8b8','#6f6f6f','#222222','#ffffff','#8b5a2b'];
    extraColors.forEach(value=>{const b=document.createElement('button');b.dataset.color=value;b.style.setProperty('--c',value);b.setAttribute('aria-label','Choose color');palette.appendChild(b)});
    const custom=document.createElement('label');custom.className='custom-color';custom.title='Choose any color';custom.innerHTML='<span>＋</span><input type="color" value="#ef3e4d" aria-label="Choose any color">';palette.appendChild(custom);
    const chooseColor=b=>{color=b.dataset.color;reader.querySelectorAll('.palette button').forEach(x=>x.classList.remove('chosen'));custom.classList.remove('chosen');b.classList.add('chosen')};
    const colorButtons=reader.querySelectorAll('[data-color]');colorButtons.forEach(b=>b.onclick=()=>chooseColor(b));if(colorButtons[0])chooseColor(colorButtons[0]);
    custom.querySelector('input').oninput=e=>{color=e.target.value;reader.querySelectorAll('.palette button').forEach(x=>x.classList.remove('chosen'));custom.classList.add('chosen')};
    reader.querySelectorAll('[data-tool]').forEach(b=>b.onclick=()=>{tool=b.dataset.tool;reader.querySelectorAll('[data-tool]').forEach(x=>x.classList.toggle('selected',x===b));reader.classList.toggle('erase-tool',tool==='erase')});
    reader.querySelectorAll('[data-size]').forEach(b=>b.onclick=()=>{brushSize=Number(b.dataset.size);reader.querySelectorAll('[data-size]').forEach(x=>x.classList.toggle('selected',x===b))});
    reader.querySelector('.undo').onclick=async()=>{if(undoStack.length<2)return;redoStack.push(undoStack.pop());await restore(undoStack.at(-1));save();updateHistory()};
    reader.querySelector('.redo').onclick=async()=>{if(!redoStack.length)return;const state=redoStack.pop();undoStack.push(state);await restore(state);save();updateHistory()};
    reader.querySelector('.compare').onclick=e=>{compare=!compare;c.style.visibility=compare?'hidden':'visible';e.currentTarget.classList.toggle('selected',compare);e.currentTarget.textContent=compare?'●':'◐'};
    reader.querySelector('.clear-paint').onclick=()=>{if(confirm('Clear all coloring on this page?')){ctx.clearRect(0,0,c.width,c.height);record()}};
    const exportCanvas=()=>{const out=document.createElement('canvas');out.width=c.width;out.height=c.height;const outCtx=out.getContext('2d');outCtx.fillStyle='#fff';outCtx.fillRect(0,0,out.width,out.height);outCtx.drawImage(c,0,0);outCtx.globalCompositeOperation='multiply';outCtx.drawImage(img,0,0,out.width,out.height);return out};
    const download=(blob,name)=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1500)};
    reader.querySelector('.save-image').onclick=()=>exportCanvas().toBlob(blob=>download(blob,`${slug}-page-${page+1}-colored.png`),'image/png');
    reader.querySelector('.save-colored-pdf').onclick=()=>download(makePdf(exportCanvas()),`${slug}-page-${page+1}-colored.pdf`);
    function makePdf(out){
      const jpeg=atob(out.toDataURL('image/jpeg',.9).split(',')[1]),enc=new TextEncoder(),parts=[],offsets=[0];let length=0;
      const addText=s=>{const b=enc.encode(s);parts.push(b);length+=b.length};const addBytes=b=>{parts.push(b);length+=b.length};
      addText('%PDF-1.4\n');
      const obj=(n,body)=>{offsets[n]=length;addText(`${n} 0 obj\n${body}\nendobj\n`)};
      obj(1,'<< /Type /Catalog /Pages 2 0 R >>');obj(2,'<< /Type /Pages /Kids [3 0 R] /Count 1 >>');
      obj(3,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>');
      offsets[4]=length;addText(`4 0 obj\n<< /Type /XObject /Subtype /Image /Width ${out.width} /Height ${out.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`);const bytes=new Uint8Array(jpeg.length);for(let i=0;i<jpeg.length;i++)bytes[i]=jpeg.charCodeAt(i);addBytes(bytes);addText('\nendstream\nendobj\n');
      const content='q 555 0 0 782 20 30 cm /Im0 Do Q';obj(5,`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
      const xref=length;addText('xref\n0 6\n0000000000 65535 f \n');for(let i=1;i<=5;i++)addText(String(offsets[i]).padStart(10,'0')+' 00000 n \n');addText(`trailer\n<< /Size 6 /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);return new Blob(parts,{type:'application/pdf'});
    }
    const applyZoom=()=>board.style.width=`${zoom*100}%`;
    const moveButton=reader.querySelector('.move-canvas');
    const setMoveMode=enabled=>{moveMode=enabled;reader.classList.toggle('move-mode',enabled);moveButton.textContent=enabled?'🖍️ Color':'✋ Move';moveButton.setAttribute('aria-pressed',String(enabled))};
    reader.querySelector('.start-coloring').onclick=()=>{zoom=1;setMoveMode(false);applyZoom();reader.classList.add('coloring')};
    reader.querySelector('.done-coloring').onclick=()=>{save();reader.classList.remove('coloring');setMoveMode(false);zoom=1;applyZoom()};
    moveButton.onclick=()=>setMoveMode(!moveMode);
    reader.querySelector('.zoom-in').onclick=()=>{zoom=Math.min(2.5,zoom+.25);applyZoom()};
    reader.querySelector('.zoom-out').onclick=()=>{zoom=Math.max(1,zoom-.25);applyZoom()};
    const activeTouches=new Map();let pinchDistance=0,pinchZoom=1,lastMid=null;
    const touchPoint=e=>({x:e.clientX,y:e.clientY});
    stage.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch')return;activeTouches.set(e.pointerId,touchPoint(e));if(activeTouches.size===2){drawing=false;const pts=[...activeTouches.values()];pinchDistance=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);pinchZoom=zoom;lastMid={x:(pts[0].x+pts[1].x)/2,y:(pts[0].y+pts[1].y)/2}}},{capture:true});
    stage.addEventListener('pointermove',e=>{if(!activeTouches.has(e.pointerId))return;activeTouches.set(e.pointerId,touchPoint(e));if(activeTouches.size===2){e.preventDefault();const pts=[...activeTouches.values()],distance=Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),mid={x:(pts[0].x+pts[1].x)/2,y:(pts[0].y+pts[1].y)/2};zoom=Math.max(1,Math.min(2.5,pinchZoom*distance/Math.max(1,pinchDistance)));applyZoom();if(lastMid){stage.scrollLeft+=lastMid.x-mid.x;stage.scrollTop+=lastMid.y-mid.y}lastMid=mid}},{passive:false});
    const endTouch=e=>{activeTouches.delete(e.pointerId);if(activeTouches.size<2)lastMid=null};stage.addEventListener('pointerup',endTouch);stage.addEventListener('pointercancel',endTouch);
  }
  draw();
}
document.querySelectorAll('.bottom-nav button').forEach(b=>b.onclick=()=>{route=b.dataset.route;render();scrollTo({top:0,behavior:'smooth'})});
if('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');
render();
